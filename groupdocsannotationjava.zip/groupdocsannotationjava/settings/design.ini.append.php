<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsannotationjava

#[StylesheetSettings]
#BackendCSSFileList[]=gdannotationjava_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdannotationjava.js
*/ ?>