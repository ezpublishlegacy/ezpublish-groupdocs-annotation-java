
[ezjscServer]
FunctionList[]=groupdocsannotationjava

[ezjscServer_groupdocsannotationjava]
Class=GroupdocsannotationjavaServerCallFunctions
File=extension/groupdocsannotationjava/classes/groupdocsannotationjavaservercallfunctions.php
//Functions[]=groupdocsannotationjava
// {*Not a valid ezjscServerRouter argument: &quot;ezjscdemo::search&quot;*}
// {*http://svn.projects.ez.no/ezjscore/trunk/packages/ezjscore_extension/documents/example/ezjscore_demo/FAQ - point 4*}

