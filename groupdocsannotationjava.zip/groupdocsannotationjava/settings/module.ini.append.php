<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsannotationjava
ModuleList[]=groupdocsannotationjava
*/ ?>