<?php /*
[NavigationPart]
Part[groupdocsannotationjavanavigationpart]=GD Annotation Java
[TopAdminMenu]
Tabs[]=groupdocsannotationjava
[Topmenu_groupdocsannotationjava]
NavigationPartIdentifier=groupdocsannotationjavanavigationpart
Name=Groupdocs Annotation for Java
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsannotationjava/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>